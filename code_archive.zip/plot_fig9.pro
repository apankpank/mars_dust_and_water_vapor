pro plot_fig9
;
; plot Figure 8 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2024

path=' ' ; enter your path to data archive
path=path+'data archive\'
 
ls34=150 ; starting Ls of MY34

set_plot, 'ps'
device, file='fig9.ps',/landscape,/color

; read CRISM and NOMAD data
fname=path+ 'crism_MY29_nomad_my34_35.dat'

file_info = QUERY_ASCII(fname,info) 
n1=info.lines

header_length=1 ; number of lines in the file header
ncols=4 ; number of data columns in the input files

temp=''
temp1=fltarr(ncols)

data=fltarr(ncols, n1-header_length)  ; data array

openr, unit, fname, /get_lun

for i=0, header_length-1 do readf, unit, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit, temp1
  data(*,i)=temp1 ; themis data
endfor

close, unit
free_lun, unit

crism_vap=data(2,*)
nomad_vap=data(3,*)
;end reading data

ind1=where(data(0,*) lt ls34, COMPLEMENT=ind2) ; ind1 is MY35, ind2 is MY34

; plotting
!x.thick=4
!y.thick=4
!x.charsize=1.5
!y.charsize=1.5
!p.charthick=4

 ttl='scaled column abudances!CNOMAD MY34-35 vs CRISM MY29'
 plot, [0,0], ytitle='NOMAD pr-!4l!Xm',xs=1,$
   xtitle='CRISM pr-!4l!Xm',psym=3,symsize=1,xrange=[0,30],ys=1,yrange=[0,30],$
   title=ttl, thick=2, /isotropic 
 loadct, 34, /silent  
 oplot, crism_vap(ind1), nomad_vap(ind1), psym=6, symsize=1, color=230, thick=4
 oplot, crism_vap(ind2), nomad_vap(ind2), psym=6, symsize=1, color=50, thick=4
 xyouts, 20, 7, 'NOMAD MY34', color=50, charsize=1.5, charthick=4
 xyouts, 20, 5, 'NOMAD MY35', color=230, charsize=1.5, charthick=4
 loadct, 0, /silent
 x1=[0,100]
 y1=x1
 oplot, x1,y1, thick=4
 oplot, 2.*x1,y1, line=2, thick=4
 
!p.multi=0
 
loadct,0, /silent

device, /close
set_plot, 'win'

end