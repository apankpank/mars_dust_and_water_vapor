pro plot_fig4_vapor
;
; plot vapor column abuindance panels in Figure 4 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2024

!p.charthick=1.0
!p.charsize=0.7

path=' ' ; enter your path to data archive
path=path+'data archive\'

my1=24
smy1=string(my1,'(i0)')

ls_1=[185., 205.,270.] ; starting Ls of the interval to plot, counted from Ls=0 MY24
nls=n_elements(ls_1)

dls=5. ;  Ls interval

fname1=path+ 'tes_vapor_spr_my'+smy1+'.dat'

ls0=(my1-24)*360. ; Ls of MY start, counting from Ls=0 in MY24

view='polar' ; plot polar plots or rectangular lat-lon plots
var='vaporsc' ; variable to plot: vapor, vapor scaled, psrf

; read data file
file_info = QUERY_ASCII(fname1,info) ; file length is the same for day and night data
n1=info.lines ; number of lines in the file

header_length=1 ; number of lines in the file header
ncols=6 ; number of data columns in the input file: Ls, Lat, LonE, Psrf (mbar), vapor (pr-mkm), err (pr-mkm)

temp=''
temp1=fltarr(ncols)

data=fltarr(ncols, n1-header_length)  ; data array

openr, unit1, fname1, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  data(*,i)=temp1
endfor

close, unit1
free_lun, unit1

ls=data(0,*)
my=24+floor(ls/360.) ; fractional MY of the TES data

lat=data(1,*) ; Latitudes
lon=data(2,*)  ; East longitudes

psrf=data(3,*)
vapor=data(4,*)
vaporsc=6.1*vapor/psrf ; scaled water vapor

; read MOLA topo
restore, ' ', DESCRIPTION=descr,RESTORED_OBJECTS=restrd
levs=(findgen(11)-5.)*2000.
clab=fltarr(11)
clab(*)=1

; for 04 resolution
lons=findgen(1440)*0.25+lonmin
lats=findgen(720)*0.25+latmin

set_plot, 'ps'
device, file='fig4_'+var+'_my'+smy1+'.ps',/portrait, /color, xsize=7.2, ysize=10.2, yoffset=1, /inches

!p.multi=[0,1,3] ; 3 maps on page, top to bottom

; square, plot symbol for 4 polar plots on page
Ax =[-1,1,1,-1,-1]*0.4
Ay=[1,1,-1,-1,1]*0.4
USERSYM, Ax, Ay, /FILL

ttl3='TES '

case var of
  'psrf' : ttl1=ttl3+'Psrf, 4-10 mbar'
  'vapor': ttl1=ttl3+'unscaled wv abundances, 0-40 pr-!4l!Xm'
  'vaporsc': ttl1=ttl3+'scaled wv abundances, 0-40 pr-!4l!Xm' 
  else: print, 'unknown variable case'
endcase


if (view eq 'polar') then begin
  ind_mola=where((lats ge -90) and (lats le -40))
  tes_lonlab=-40
endif else begin
  ind_mola=where((lats ge -90) and (lats le 90))
endelse

for i=0, nls-1 do begin

  ls1=ls_1(i)
  ls2=ls1+dls
  
  ls11=ls1-ls0
  ls22=ls2-ls0

  if (view eq 'polar') then $
    ; select data for given year and ls interval, for south polar study region (-90 - -40) 
    ind=where((ls ge ls1) and (ls lt ls2) and (lat le -40.) and $   
      + (var eq 'vaporsc')) $  ; vapor selection     
    else ind=where((ls ge ls1) and (ls lt ls2) and $; cylindrical projection
      + (var eq 'vaporsc'))  ; vapor selection

  ttl=ttl1+'!C'+$
    'MY'+smy1+' Ls='+string(ls11,'(i0)')+'-'+string(ls22,'(i0)')

  if (view eq 'polar') then map_set, /lambert, -90, 0, 0, /isotropic,/advance,limit=[-40,0,-40,360],title=ttl else $; south pole from 40 to 90'
    map_set, /cylindrical, 0, 0, 0, /isotropic,/advance,title=ttl

  loadct, 34, /silent
  case var of
    'psrf':    plots, lon(ind),lat(ind),psym=8, color=fix(255*(psrf(ind)-4.)/6.),symsize=1
    'vapor':   plots, lon(ind),lat(ind),psym=8, color=fix(255*vapor(ind)/40.),symsize=1
    'vaporsc': plots, lon(ind),lat(ind),psym=8, color=fix(255*vaporsc(ind)/40.),symsize=1   
    else: print, 'unknown variable case'
  endcase

  loadct, 0, /silent

  contour, molagrid(*,ind_mola),lons,lats(ind_mola),levels=levs,/overplot,thick=1,c_labels=clab,/follow,color=125
  if (view eq 'polar') then map_grid, glinestyle=1, glinethick=2, charsize=1.,latdel=10,londel=45, label=1, charthick=2, lonlab=spicam_lonlab else $
    map_grid, glinestyle=1, glinethick=2, charsize=1.,latdel=30,londel=45, label=1, charthick=2

endfor

!p.multi=0

; plot color bar
; square plot symbol
Ax =[-1,1,1,-1,-1]*0.7
Ay=[1,1,-1,-1,1]*2.
USERSYM, Ax, Ay, /FILL

!p.multi=[0,1,2]
; set up coordinates
!p.charsize=1.5
!p.charthick=4.0

xb=50
yb=-185

case 1 of
  (var eq 'vapor') or (var eq 'vaporsc'): begin
    plot,[0,0],[0,0],xrange=[0,360],xs=1,yrange=[-90,90],ys=1,xtitle='vapor column abundance, pr-!4l!Xm',$
      xtickinterval=360,ytickinterval=30    
    loadct, 34, /silent
    for i=0,255 do plots, xb+5+i, yb+24, psym=8, color=i, symsize=1
    loadct,0, /silent
    ; plot color bar scale 0-40, 5 interval
    for i=0,4 do xyouts, xb+i*255./4.,yb, string(i*10,'(i0)'),charthick=3,charsize=1.5 ; maxv=40
  end
  else:  print, 'unknown variable case'
endcase

!p.multi=0
!p.charthick=1
!p.charsize=1

device, /close
set_plot, 'win'

end