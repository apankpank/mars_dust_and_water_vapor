pro plot_fig3

; plot Figure 3 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2024

path=' ' ; enter your path to data archive
path=path+'data archive\'

ltm='day' ; daytime data

fname1=path+ 'tes_zonal_MY24_'+ltm+'.dat' 
fname2=path+ 'tes_zonal_MY25_'+ltm+'.dat'

vap_plot=1
dust_plot=1

file_info = QUERY_ASCII(fname1,info) ; file length is the same for day and night data
n1=info.lines ; number of lines in the file

dlat=10. ; latitude interval
dls=5. ; Ls interval, deg

header_length=6 ; number of lines in the file header
ncols=9 ; number of data columns in the input file: Ls, Lat, n, vapor (scled) pr-mkm, vapor var, dust (scaled), dust var, Tsrf K, Tsrf var

temp=''
temp1=fltarr(ncols) 

data=fltarr(2, ncols, n1-header_length)  ; data array

openr, unit1, fname1, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  data(0, *,i)=temp1
endfor

openr, unit2, fname2, /get_lun

for i=0, header_length-1 do readf, unit2, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit2, temp1
  data(1, *,i)=temp1
endfor

close, unit1, unit2
free_lun, unit1, unit2

set_plot, 'ps'
device, file='fig3.ps',/portrait,/color, xsize=7.2, ysize=10.2, yoffset=1, /inches

sms=0.8 ; symsize in plot
chs=0.8 ; character size in plot legend

!x.thick=2
!y.thick=2
!x.charsize=1.8
!y.charsize=1.8
!p.charthick=2
!p.charsize=1.

ls1=data(0,0,*)
ls2=data(1,0,*)

ttl1='water vapor'
ttl2='dust'

!p.multi=[0,2,5]

for j=0, 4 do begin ; cycle over latitudinal bands
 lat1=-90+dlat*j
 lat2=lat1+dlat

 if (lat1 lt 0 and lat2 lt 0) then lat_band=' Lat='+string(-lat1,'(i0)')+'S-'+string(-lat2,'(i0)')+'S' else $
   lat_band=' Lat='+string(lat1,'(f4.1)')+'N-'+string(lat2,'(f4.1)')+'N'

; scaled water vapor plot
 if (vap_plot) then begin
  ind1=where((data(0,1,*) eq lat1) and (data(0,3,*) gt 0)) ; find non-zero vapor data in a latitudinal band in file1
  if (ind1(0) ne -1) then begin
   ls1=data(0,0,ind1)
   vap1=data(0,3,ind1)
   vap_err1=data(0,4,ind1)
  endif

  ind2=where((data(1,1,*) eq lat1) and (data(1,3,*) gt 0)) ; find non-zero vapor data in a latitudinal band in file2
  if (ind2(0) ne -1) then begin
   ls2=data(1,0,ind2)
   vap2=data(1,3,ind2)
   vap_err2=data(1,4,ind2)
  endif  
 
 if (j eq 0) then ttl=ttl1 else ttl=''
  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[0,60], ys=1, title=ttl, thick=2, $
    xtickinterval=30., xminor=3, xtitle='Ls', ytitle='wv abundance, pr-!4l!Xm' 
  if (ind1(0) ne -1) then begin
   loadct, 34, /silent
   oplot, ls1+dls/2., vap1, psym=-6, thick=2, color=20, symsize=sms
   loadct, 0, /silent
  endif
  if (ind2(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls2+dls/2., vap2, psym=-6, thick=2, color=250, symsize=sms
    loadct, 0, /silent    
  endif

  ; plot  legend
  if (j eq 0) then begin
   x0=[190,210]
   y0=[50,50]
   loadct, 34, /silent
   oplot, x0, y0, psym=-6, thick=2,  color=20, symsize=sms
   oplot, x0, y0-5, psym=-6, thick=2,  color=250, symsize=sms
   loadct, 0, /silent
   xyouts, x0[1]+5, y0[0], 'TES MY24 wv', charsize=chs
   xyouts, x0[1]+5, y0[0]-5, 'TES MY25 wv', charsize=chs
  endif  
 endif 

; pressure-scaled dust plot
 if (dust_plot) then begin
  ind1=where((data(0,1,*) eq lat1) and (data(0,5,*) gt 0)) ; find non-zero dust data in a latitudinal band in file1
  if (ind1(0) ne -1) then begin
   ls1=data(0,0,ind1)
   dust1=data(0,5,ind1)
   dust_err1=data(0,6,ind1)
  endif

  ind2=where((data(1,1,*) eq lat1) and (data(1,5,*) gt 0)) ; find non-zero dust data in a latitudinal band in file2
  if (ind2(0) ne -1) then begin
   ls2=data(1,0,ind2)
   dust2=data(1,5,ind2)
   dust_err2=data(1,6,ind2)
  endif

 if (j eq 0) then ttl=ttl2 else ttl=''
  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[0,3.], title=ttl, ys=1, thick=2, $
   xtickinterval=30., xminor=3, xtitle='Ls', ytitle='dust opacity'
  if (ind1(0) ne -1) then begin
   loadct, 34, /silent
   oplot, ls1+dls/2., dust1, psym=-6, thick=2, color=20, symsize=sms
   loadct, 0, /silent
  endif
  if (ind2(0) ne -1) then begin
   loadct, 34, /silent
   oplot, ls2+dls/2., dust2, psym=-6, thick=2, color=250, symsize=sms
   loadct, 0, /silent
  endif
  
  ; plot  legend
  if (j eq 0) then begin
    x0=[190,210]
    y0=[2.6,2.6]
    loadct, 34, /silent
    oplot, x0, y0, psym=-6, thick=2,  color=20, symsize=sms
    oplot, x0, y0-0.3, psym=-6, thick=2,  color=250, symsize=sms
    loadct, 0, /silent
    xyouts, x0[1]+5, y0[0], 'TES MY24 dust', charsize=chs
    xyouts, x0[1]+5, y0[0]-0.3, 'TES MY25 dust', charsize=chs
  endif
  ; plot zonal band limits
  x1=[290,290]
  y1=[2.5,2.5]
  xyouts, x1[0], y1[0], lat_band, charsize=chs
  
 endif
endfor 

!p.multi=0

device, /close
set_plot, 'win'

!x.thick=1
!y.thick=1
!x.charsize=1
!y.charsize=1
!p.charthick=1
!p.charsize=1

end