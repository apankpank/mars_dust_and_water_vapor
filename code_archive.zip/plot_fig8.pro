pro plot_fig8
;
; plot Figure 8 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2024

path='D:\Users\Alex\Documents\Science\SSI\MDAP 2020 JPL water vapor\manuscript 1\' ; enter your path to data archive
path=path+'data archive\'

my1=29
my2=28 ; gds year

ltm='day'
smy1='MY'+string(my1,'(i0)')
smy2='MY'+string(my2,'(i0)')

themis_fname=path+ 'themis_zonal_'+smy2+'.dat' ; THEMIS my 28

mcs_fname=path+ 'mcs_zonal_'+smy1+'_'+ltm+'.dat' ; MCS my29 day

tsrf_plot=1

dlat=10. ; latitude band width, deg
dls=5. ; Ls interval, deg

; Reading THEMIS data
file_info = QUERY_ASCII(themis_fname,info) ; file length is the same for MCS and THEMIS data files
n1=info.lines

cext_ratio=2.5 ; ratio of dust Cext(1075 cm-1)/Cext(465cm-1) to convert to TES dust opacity; 2.6, 2.2 and 1.9 for 1.0, 1.5 and 2.0 mkm dust

header_length=4 ; number of lines in the file header
ncols=9 ; number of data columns in the input files

temp=''
temp1=fltarr(ncols)

data=fltarr(2, ncols, n1-header_length)  ; data array

openr, unit1, themis_fname, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  data(0, *,i)=temp1 ; themis data
endfor

; Reading MCS data
openr, unit2, mcs_fname, /get_lun

for i=0, header_length-1 do readf, unit2, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit2, temp1
  data(1, *,i)=temp1 ; MCS data
endfor

; close mcs and themis data files
close, unit1, unit2
free_lun, unit1, unit2

mcs_themis_data=data

set_plot, 'ps'
device, file='fig8.ps',/portrait,/color, xsize=7.2, ysize=10.2, yoffset=1, /inches

sms=0.8 ; symsize in plot
chs=0.8 ; character size in plot legend

!x.thick=2
!y.thick=2
!x.charsize=1.8
!y.charsize=1.8
!p.charthick=2
!p.charsize=1.0

ls1=data(0,0,*)
ls2=data(1,0,*)

ttl1='T!Dsurf!N '+ltm

!p.multi=[0,2,5,1,1]

for j=0, 4 do begin ; cycle over latitudinal bands
 lat1=-90+dlat*j
 lat2=lat1+dlat
 
 ; does not capture the case when crossing equator
 if (lat1 lt 0 and lat2 lt 0) then lat_band=' Lat='+string(-lat1,'(i0)')+'S-'+string(-lat2,'(i0)')+'S' else $
   lat_band=' Lat='+string(lat1,'(f4.1)')+'N-'+string(lat2,'(f4.1)')+'N'

; Tsrf plot
 if (tsrf_plot) then begin

 ind1=where((data(0,1,*) eq lat1) and (data(0,2,*) gt 0)) ; find non-zero daytime data in a latitudinal band in THEMIS data
  if (ind1(0) ne -1) then begin
    ls1=data(0,0,ind1)
    tsurf1=data(0,7,ind1)
    tsurf_err1=data(0,8,ind1)
  endif

 ind2=where((data(1,1,*) eq lat1) and (data(1,2,*) gt 10)) ; find non-zero daytime data in a latitudinal band in MCS data
  if (ind2(0) ne -1) then begin
   ls2=data(1,0,ind2)
   tsurf2=data(1,7,ind2)
   tsurf_err2=data(1,8,ind2)
  endif

  if (j eq 0 ) then ttl=ttl1 else ttl=''
  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[120,320.], ys=1, title=ttl , thick=2,$
    xtickinterval=30., xminor=3, xtitle='Ls', ytitle='Temperature, K'
  if (ind1(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls1+dls/2., tsurf1, psym=-6, thick=2, color=250, symsize=sms
    loadct, 0, /silent
  endif
  if (ind2(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls2+dls/2., tsurf2, psym=-6, thick=2, color=20, symsize=sms
    loadct, 0, /silent
  endif 
  
  ; plot  legend
  if (j eq 0) then begin
    x0=[190,210]
    y0=[300,300]
    loadct, 34, /silent
    oplot, x0, y0, psym=-6, thick=2,  color=250, symsize=sms
    oplot, x0, y0-20, psym=-6, thick=2,  color=20, symsize=sms
    loadct, 0, /silent
    xyouts, x0[1]+5, y0[0], 'THEMIS '+smy2+' T!Dsurf!N', charsize=chs
    xyouts, x0[1]+5, y0[0]-20, 'MCS '+smy1+' T!Dsurf!N', charsize=chs
  endif
  ; plot zonal band limits
  x1=[290,290]
  y1=[140,140]
  xyouts, x1[0], y1[0], lat_band, charsize=chs
 endif
endfor 

!p.multi=0

device, /close
set_plot, 'win'

!x.thick=1
!y.thick=1
!x.charsize=1
!y.charsize=1
!p.charthick=1
!p.charsize=1

end