pro plot_fig6
;
; plot Figure 6 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2024

path=' ' ; enter your path to data archive
path=path+'data archive\'

my1=29
my2=28 ; gds year

ltm='day'
smy1='MY'+string(my1,'(i0)')
smy2='MY'+string(my2,'(i0)')

fname1=path+ 'spicam_zonal_'+smy1+'_'+ltm+'.dat' ; spicam MY29 day
fname2=path+ 'spicam_zonal_'+smy2+'_'+ltm+'.dat' ; spicam MY28 day

themis_fname=path+ 'themis_zonal_'+smy2+'.dat' ; THEMIS my 28 day

mcs_fname=path+ 'mcs_zonal_'+smy1+'_'+ltm+'.dat' ; MCS my29 day

vap_plot=1
dust_plot=1
tsrf_plot=0


; Reading SPICAM data
file_info = QUERY_ASCII(fname1,info) ; file length is the same foir day and night data
n1=info.lines

dlat=10. ; latitude band width, deg
dls=5. ; Ls interval, deg

header_length=6 ; number of lines in the file header
ncols=5 ; number of data columns in the input file: Ls, Lat, n, vapor pr-mkm (scaled), vapor var

temp=''
temp1=fltarr(ncols) 

spicam_data=fltarr(2, ncols, n1-header_length)  ; data array

openr, unit1, fname1, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  spicam_data(0, *,i)=temp1
endfor

openr, unit2, fname2, /get_lun

for i=0, header_length-1 do readf, unit2, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit2, temp1
  spicam_data(1, *,i)=temp1
endfor

close, unit1, unit2
free_lun, unit1, unit2

; Reading THEMIS data
file_info = QUERY_ASCII(themis_fname,info) ; file length is the same for MCS and THEMIS data files
n1=info.lines

cext_ratio=2.5 ; ratio of dust Cext(1075 cm-1)/Cext(465cm-1) to convert to TES dust opacity; 2.6, 2.2 and 1.9 for 1.0, 1.5 and 2.0 mkm dust

header_length=4 ; number of lines in the file header
ncols=9 ; number of data columns in the input files

temp=''
temp1=fltarr(ncols)

data=fltarr(2, ncols, n1-header_length)  ; data array

openr, unit1, themis_fname, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  data(0, *,i)=temp1 ; themis data
endfor

; Reading MCS data
openr, unit2, mcs_fname, /get_lun

for i=0, header_length-1 do readf, unit2, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit2, temp1
  data(1, *,i)=temp1 ; MCS data
endfor

; close mcs and themis data files
close, unit1, unit2
free_lun, unit1, unit2

mcs_themis_data=data

set_plot, 'ps'
device, file='fig6.ps',/portrait,/color, xsize=7.2, ysize=10.2, yoffset=1, /inches

sms=0.8 ; symsize in plot
chs=0.8 ; character size in plot legend

!x.thick=2
!y.thick=2
!x.charsize=1.8
!y.charsize=1.8
!p.charthick=2
!p.charsize=1.0

ls1=data(0,0,*)
ls2=data(1,0,*)

ttl1='water vapor'
ttl2='dust'

!p.multi=[0,2,5]

for j=0, 4 do begin ; cycle over latitudinal bands
 lat1=-90+dlat*j
 lat2=lat1+dlat
 
 ; does not capture the case when crossing equator
 if (lat1 lt 0 and lat2 lt 0) then lat_band=' Lat='+string(-lat1,'(i0)')+'S-'+string(-lat2,'(i0)')+'S' else $
   lat_band=' Lat='+string(lat1,'(f4.1)')+'N-'+string(lat2,'(f4.1)')+'N'
 
 data=spicam_data

 ; scaled water vapor plot
 if (vap_plot) then begin

  ind1=where((data(0,1,*) eq lat1) and (data(0,2,*) gt 1)) ; find non-zero daytime data in a latitudinal band in file1
  ind2=where((data(1,1,*) eq lat1) and (data(1,2,*) gt 1)) ; find non-zero daytime data in a latitudinal band in file 2

  if (ind1(0) ne -1) then begin
   ls1=data(0,0,ind1)
   vap1=data(0,3,ind1)
   vap_err1=data(0,4,ind1)
  endif 

  if (ind2(0) ne -1) then begin
   ls2=data(1,0,ind2)
   vap2=data(1,3,ind2)
   vap_err2=data(1,4,ind2)
  endif  
 
 if (j eq 0 ) then ttl=ttl1 else ttl=''
  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[0,60], ys=1, title=ttl, thick=2, $
    xtickinterval=30., xminor=3, xtitle='Ls', ytitle='wv abundance, pr-!4l!Xm'  
  if (ind1(0) ne -1) then begin
   loadct, 34, /silent
   oplot, ls1+dls/2., vap1, psym=-6, thick=2, color=20, symsize=sms ; my29
   loadct, 0, /silent
  endif
  if (ind2(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls2+dls/2., vap2, psym=-6, thick=2, color=250, symsize=sms ; my28
    loadct, 0, /silent    
  endif

  ; plot  legend
  if (j eq 0) then begin
   x0=[190,210]
   y0=[50,50]
   loadct, 34, /silent
   oplot, x0, y0, psym=-6, thick=2,  color=250, symsize=sms
   oplot, x0, y0-5, psym=-6, thick=2,  color=20, symsize=sms
   loadct, 0, /silent
   xyouts, x0[1]+5, y0[0], 'SPICAM '+smy2+' wv', charsize=chs
   xyouts, x0[1]+5, y0[0]-5, 'SPICAM '+smy1+' wv', charsize=chs
  endif  
 endif 

; pressure-scaled dust plot
 if (dust_plot) then begin
  
  data=mcs_themis_data
  
  ind1=where((data(0,1,*) eq lat1) and (data(0,2,*) gt 0)) ; find non-zero daytime data in a latitudinal band in themis data
  if (ind1(0) ne -1) then begin
   ls1=data(0,0,ind1)

   dust1=data(0,3,ind1) ; scaled dust THEMIS
   dust_err1=data(0,4,ind1)
 
   tsurf1=data(0,7,ind1)
   tsurf_err1=data(0,8,ind1) 
  endif 

  ind2=where((data(1,1,*) eq lat1) and (data(1,2,*) gt 10)) ; find non-zero daytime data in a latitudinal band in mcs data
  if (ind2(0) ne -1) then begin
    ls2=data(1,0,ind2)

    dust2=data(1,3,ind2) ; psurf scaled dust MCS
    dust_err2=data(1,4,ind2)
    dust2_tes=cext_ratio*dust2 ; psurf scaled dust opacity converted to opacity at 1075 cm-1
    dust_err2_tes=cext_ratio*dust_err2

    tsurf2=data(1,7,ind2)
    tsurf_err2=data(1,8,ind2)
  endif

  if (j eq 0) then ttl=ttl2 else ttl=''
  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[0,3.], ys=1, title=ttl , thick=2, $
   xtickinterval=30., xminor=3, xtitle='Ls', ytitle='dust opacity'
  if (ind1(0) ne -1) then begin
   loadct, 34, /silent
   oplot, ls2+dls/2., dust2_tes, psym=-6, thick=2, color=20, symsize=sms ; MCS
   loadct, 0, /silent
  endif
  if (ind2(0) ne -1) then begin
   loadct, 34, /silent
   oplot, ls1+dls/2., dust1, psym=-6, thick=2, color=250, symsize=sms ; THEMIS
   loadct, 0, /silent
  endif
  
; plot  legend
  if (j eq 0) then begin
    x0=[190,210]
    y0=[2.6,2.6]
    loadct, 34, /silent
    oplot, x0, y0, psym=-6, thick=2,  color=250, symsize=sms
    oplot, x0, y0-0.3, psym=-6, thick=2,  color=20, symsize=sms
    loadct, 0, /silent
    xyouts, x0[1]+5, y0[0], 'THEMIS '+smy2+' dust', charsize=chs
    xyouts, x0[1]+5, y0[0]-0.3, 'MCS '+smy1+' dust', charsize=chs
  endif

; plot zonal band limits
  x1=[290,290]
  y1=[50,50]
  xyouts, x1[0], y1[0], lat_band, charsize=chs
  
endif

; Tsrf plot
 if (tsrf_plot) then begin
  ind1=where((data(0,1,*) eq lat1) and (data(0,9,*) gt 0)) ; find non-zero Tsrf data in a latitudinal band in file1
  if (ind1(0) ne -1) then begin
    ls1=data(0,0,ind1)
    tsurf1=data(0,9,ind1)
    tsurf_err1=data(0,10,ind1)
  endif

  ind2=where((data(1,1,*) eq lat1) and (data(1,9,*) gt 0)) ; find non-zero Tsrf data in a latitudinal band in file2
  if (ind2(0) ne -1) then begin
   ls2=data(1,0,ind2)
   tsurf2=data(1,9,ind2)
   tsurf_err2=data(1,10,ind2)
  endif

  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[120,320.], ys=1, title=ttl1+' Tsurf,'+lat_band , thick=2,$
    xtickinterval=30., xminor=3, xtitle='Ls', ytitle='Temperature, K'
  if (ind1(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls1+dls/2., tsurf1, psym=-6, thick=2, color=250, symsize=sms
    loadct, 0, /silent
  endif
  if (ind2(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls2+dls/2., tsurf2, psym=-6, thick=2, color=20, symsize=sms
    loadct, 0, /silent
  endif 
 endif
endfor 

!p.multi=0

device, /close
set_plot, 'win'

!x.thick=1
!y.thick=1
!x.charsize=1
!y.charsize=1
!p.charthick=1
!p.charsize=1

end