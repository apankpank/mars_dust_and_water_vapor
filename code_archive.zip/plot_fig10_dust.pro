pro plot_fig10_dust
;
; plot dust panel of Figure 10 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2024

path='  ' ; enter your path to data archive
path=path+'data archive\'

my1=29
my2=34
ltm='day'
smy1='my'+string(my1,'(i0)')
smy2='my'+string(my2,'(i0)')
fname1=path+ 'mcs_zonal_'+smy1+'_'+ltm+'.dat'
fname2=path+ 'mcs_zonal_'+smy2+'_'+ltm+'.dat'

cext_ratio=2.5 ; ratio of dust Cext(1075 cm-1)/Cext(465cm-1) to convert to TES dust opacity; 2.6, 2.2 and 1.9 for 1.0, 1.5 and 2.0 mkm dust

file_info = QUERY_ASCII(fname1,info) ; file length is the same foir day and night data
n1=info.lines

dlat=10. ; latitude band width, deg
dls=5. ; Ls interval, deg

header_length=4 ; number of lines in the file header
ncols=9 ; number of data columns in the input file: Ls, Lat, n, scaled dust 465 mkm, dust var, unscaled dust 465 mkm, dust var, tsrf K, tsrf var

temp=''
temp1=fltarr(ncols) 

data=fltarr(2, ncols, n1-header_length)  ; data array

openr, unit1, fname1, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  data(0, *,i)=temp1
endfor

openr, unit2, fname2, /get_lun

for i=0, header_length-1 do readf, unit2, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit2, temp1
  data(1, *,i)=temp1
endfor

close, unit1, unit2
free_lun, unit1, unit2

set_plot, 'ps'
device, file='fig10_dust.ps', /portrait, /color, xsize=7.2, ysize=10.2, yoffset=1, /inches

sms=0.8 ; symsize in plot
chs=0.8 ; character size in plot legend

!x.thick=2
!y.thick=2
!x.charsize=1.8
!y.charsize=1.8
!p.charthick=2
!p.charsize=1.0

ttl1='scaled dust 1075 cm!U-1!N'
ttl2=ltm+' Tsrf'

!p.multi=[0,2,5,0,1]

for j=0, 4 do begin ; cycle over latitudinal bands
  lat1=-90+dlat*j
  lat2=lat1+dlat
 ind1=where((data(0,1,*) eq lat1) and (data(0,2,*) gt 10)) ; find non-zero daytime data in a latitudinal band in file1
 ind2=where((data(1,1,*) eq lat1) and (data(1,2,*) gt 10)) ; find non-zero daytime data in a latitudinal band in file 2

 if (ind1(0) ne -1) then begin
  ls1=data(0,0,ind1)
  dust1=data(0,3,ind1) ; psurf scaled dust
  dust1_tes=cext_ratio*dust1 ; conversion from opacity at 465 cm-1 to 1075 cm-1
 endif 

 if (ind2(0) ne -1) then begin
   ls2=data(1,0,ind2)
   dust2=data(1,3,ind2)
   dust2_tes=cext_ratio*dust2 ; conversion from opacity at 465 cm-1 to 1075 cm-1
 endif
  
  ; does not capture the case when crossing equator
  if (lat1 lt 0 and lat2 lt 0) then lat_band=' Lat='+string(-lat1,'(i0)')+'S-'+string(-lat2,'(i0)')+'S' else $ 
   lat_band=' Lat='+string(lat1,'(f4.1)')+'N-'+string(lat2,'(f4.1)')+'N'

 if (j eq 0 ) then ttl=ttl1 else ttl=''
  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[0,3.0], ys=1, title=ttl , thick=2,$
    xtickinterval=30., xminor=3, xtitle='Ls', ytitle='dust opacity'
  if (ind1(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls1+dls/2., dust1_tes, psym=-6, thick=2, color=20, symsize=sms
    loadct, 0, /silent
  endif
  if (ind2(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls2+dls/2., dust2_tes, psym=-6, thick=2, color=250, symsize=sms
    loadct, 0, /silent
  endif  
  
; plot  legend
  if (j eq 0) then begin
   x0=[190,210]
   y0=[2.7,2.7]
   loadct, 34, /silent
   oplot, x0, y0, psym=-6, thick=2,  color=20, symsize=sms
   oplot, x0, y0-0.3, psym=-6, thick=2,  color=250, symsize=sms
   loadct, 0, /silent
   xyouts, x0[1]+5, y0[0], 'MCS '+smy1+' dust', charsize=chs
   xyouts, x0[1]+5, y0[0]-0.3, 'MCS '+smy2+' dust', charsize=chs
  endif
      
  ; plot zonal band limits
  x1=[290,290]
  y1=[2.5,2.5]
  xyouts, x1[0], y1[0], lat_band, charsize=chs

endfor 

!p.multi=0

device, /close
set_plot, 'win'

end