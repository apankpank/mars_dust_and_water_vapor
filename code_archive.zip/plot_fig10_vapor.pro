pro plot_fig10_vapor
;
; plot water vapor panel of Figure 10 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2024

path='  ' ; enter your path to data archive
path=path+'data archive\'

my1=34
my2=29
ltm='day'
smy1='MY'+string(my1,'(i0)')
smy2='MY'+string(my2,'(i0)')
fname1=path+ 'nomad_zonal_'+smy1+'.dat' ; NOMAD data

fname2=path+ 'crism_zonal_'+smy2+'.dat'

file_info = QUERY_ASCII(fname1,info) ; file length is the same for both files
n1=info.lines

dlat=10. ; latitude band width, deg
dls=5. ; Ls interval, deg

header_length=4 ; number of lines in NOMAD file header
ncols1=7 ; number of data columns in NOMAD input file: Ls, lat, n, vap_sc, vap var, dust, dust var

temp=''
temp1=fltarr(ncols1) 

data=fltarr(2, ncols1, n1-header_length)  ; data array

openr, unit1, fname1, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  data(0, *,i)=temp1
endfor

header_length=4 ; number of lines in CRISM file header
ncols2=5 ; number of data columns in CRISM input file: Ls, lat, n, vap_sc, vap var

temp2=fltarr(ncols2) 

openr, unit2, fname2, /get_lun

for i=0, header_length-1 do readf, unit2, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit2, temp2
  data(1, 0:ncols2-1,i)=temp2
endfor

close, unit1, unit2
free_lun, unit1, unit2

!p.multi=[0,2,5,1,1]

set_plot, 'ps'
device, file='fig10_vapor.ps',/portrait,/color, xsize=7.2, ysize=10.2, yoffset=1, /inches

sms=0.8 ; symsize in plot
chs=0.8 ; character size in plot legend

!x.thick=2
!y.thick=2
!x.charsize=1.8
!y.charsize=1.8
!p.charthick=2
!p.charsize=1.0

ttl1='water vapor'
ttl2='dust'

for j=0, 4 do begin ; cycle over latitudinal bands
  lat1=-90+dlat*j
  lat2=lat1+dlat
 ind1=where((data(0,1,*) eq lat1) and (data(0,3,*) gt 0)) ; find non-zero daytime data in a latitudinal band in file1
 ind2=where((data(1,1,*) eq lat1) and (data(1,3,*) gt 0)) ; find non-zero daytime data in a latitudinal band in file 2

 if (ind1(0) ne -1) then begin
  ls1=data(0,0,ind1)
  vap1=data(0,3,ind1)
  vap_err1=data(0,4,ind1)
 endif 

 if (ind2(0) ne -1) then begin
   ls2=data(1,0,ind2)
   vap2=data(1,3,ind2)
   vap_err2=data(1,4,ind2)
 endif
  
  ; does not capture the case when crossing equator
  if (lat1 lt 0 and lat2 lt 0) then lat_band=' lat='+string(-lat1,'(f4.1)')+'S-'+string(-lat2,'(f4.1)')+'S' else $ 
   lat_band=' lat='+string(lat1,'(f4.1)')+'N-'+string(lat2,'(f4.1)')+'N'
     
  if (j eq 0 ) then ttl=ttl1 else ttl=''
  plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[0,60], ys=1, title=ttl , thick=2,$
    xtickinterval=30., xminor=3, xtitle='Ls', ytitle='wv abundance, pr-!4l!Xm'  
  if (ind1(0) ne -1) then begin
   loadct, 34, /silent
   oplot, ls1+dls/2., vap1, psym=-6, thick=2, color=250, symsize=sms
   loadct, 0, /silent 
  endif
  if (ind2(0) ne -1) then begin
    loadct, 34, /silent
    oplot, ls2+dls/2., vap2, psym=-6, thick=2, color=20, symsize=sms
    loadct, 0, /silent    
  endif  

  if (j eq 0) then  begin
  ; plot  legend
   x0=[190,210]
   y0=[55,55]
   loadct, 34, /silent
   oplot, x0, y0, psym=-6, thick=2,  color=20, symsize=sms
   oplot, x0, y0-5, psym=-6, thick=2,  color=250, symsize=sms
   loadct, 0, /silent
   xyouts, x0[1]+5, y0[0], 'CRISM '+smy2+' wv', charsize=chs
   xyouts, x0[1]+5, y0[0]-5, 'NOMAD '+smy1+' wv', charsize=chs
  endif
 
endfor 

!p.multi=0

device, /close
set_plot, 'win'

!x.thick=1
!y.thick=1
!x.charsize=1
!y.charsize=1
!p.charthick=1
!p.charsize=1

end