pro plot_fig2

; plot Figure 2 in Pankine, A. A., Leung, C., Tamppari, L.,
; Martinez, G., Giuranna, M., Piqueux, S.,
; et al. (2023). Effects of global dust storms
; on water vapor in the Southern Polar
; Region of Mars. Journal of Geophysical
; Research: Planets, 128, e2023JE008016.
; https://doi.org/10.1029/2023JE008016
; 
; 
; Alexey Pankine (c) 2023

path=' ' ; enter your path to data archive
path=path+'data archive\'

; read TES data
tes_fname1=path+ 'tes_zonal_MY24_40_60S.dat' ; TES data for MY24
tes_fname2=path+ 'tes_zonal_MY25_40_60S.dat' ; TES data for MY25

header_length=5 ; number of lines in the file header
ncols=5 ; number of data columns in the input file: Ls, lat, n, dust, dust var
n1=41 ; number of lines in the file

temp=''
temp1=fltarr(ncols)

tes_data=fltarr(2, ncols, n1-header_length)  ; tes data array

openr, unit1, tes_fname1, /get_lun
openr, unit2, tes_fname2, /get_lun

for i=0, header_length-1 do readf, unit1, temp ; skip header
for i=0, header_length-1 do readf, unit2, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit1, temp1
  tes_data(0, *,i)=temp1
  readf, unit2, temp1
  tes_data(1, *,i)=temp1
endfor

close, unit1, unit2
free_lun, unit1, unit2

lat_band=' lat=40-60S'
lat1=-60 ; latitude of southern boundary
dls=5. ; width of the Ls interval

; dust plot
ind1=where((tes_data(0,1,*) eq lat1) and (tes_data(0,3,*) gt 0)) ; find non-zero data in a latitudinal band in file1
if (ind1(0) ne -1) then begin
  ls1=tes_data(0,0, ind1)
  tes_dust1=tes_data(0,3, ind1)
endif

ind2=where((tes_data(1,1,*) eq lat1) and (tes_data(1,3,*) gt 0)) ; find non-zero vapor data in a latitudinal band in file2
if (ind2(0) ne -1) then begin
  ls2=tes_data(1,0,ind2)
  tes_dust2=tes_data(1,3,ind2)
endif

set_plot, 'ps'
device, file='fig2.ps',/landscape,/color

!p.charthick=4
!p.charsize=1.5
!x.thick=4
!y.thick=4

plot, [0,0], [0,0], psym=3, xrange=[180,360] , xs=1, yrange=[0,3.], ys=1, title='Scaled dust opacities at 9.3 !4l!Xm!CMY24, 25, 28 and 34 '+lat_band , thick=2,$
  xtickinterval=30., xminor=3, xtitle='Ls', ytitle='dust opacity'
loadct, 38, /silent
oplot, ls1+dls/2., tes_dust1, psym=-6, thick=3, color=0
oplot, ls2+dls/2., tes_dust2, psym=-5, thick=3, color=70

; plot  legend
x0=[240,260]
y0=[2.8,2.8]
oplot, x0, y0, psym=-6, thick=3,  color=0
oplot, x0, y0-0.15, psym=-5, thick=3,  color=70
loadct, 0, /silent
xyouts, x0[1]+5, y0[0], 'TES MY24'
xyouts, x0[1]+5, y0[0]-0.15, 'TES MY25'


;***********
; read THEMIS dust opacity data for MY28 (1075 cm-1)

themis_fname=path+'themis_zonal_MY28_40_60S.dat'

header_length=4 ; number of lines in the file header
ncols=7 ; number of data columns in the input file: Ls, Lat, n, dust (scaled), dust var, Tsrf K, Tsrf var
n1=40 ; number of lines in flie

temp1=fltarr(ncols)

themis_data=fltarr(ncols, n1-header_length)  ; THEMIS data array

openr, unit, themis_fname, /get_lun

for i=0, header_length-1 do readf, unit, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit, temp1
  themis_data(*,i)=temp1
endfor

close, unit
free_lun, unit

ind=where((themis_data(1,*) eq lat1) and (themis_data(2,*) gt 0)) ; find non-zero data in a latitudinal band
if (ind(0) ne -1) then begin
  ls=themis_data(0,ind)
  themis_dustsc=themis_data(3,ind)
  loadct, 38, /silent
  oplot, ls+dls/2., themis_dustsc, psym=-2, thick=3, color=90
  
; plot  legend
  oplot, x0, y0-0.3, psym=-2, thick=3,  color=90
  loadct, 0, /silent
  xyouts, x0[1]+5, y0[0]-0.3, 'THEMIS MY28'
endif   


;***********
; read MCS dust opacity data for MY33 at 463 cm-1

mcs_fname=path+ 'mcs_zonal_MY34_40_60S.dat'

header_length=4 ; number of lines in the file header
ncols=9 ; number of data columns in the input file: Ls, lat, n, dustsc, dustsc var, dust, dust var, tsrf, tsrf var
n1=40 ; number of lines in flie

temp1=fltarr(ncols)

mcs_data=fltarr(ncols, n1-header_length)  ; data array

openr, unit, mcs_fname, /get_lun

for i=0, header_length-1 do readf, unit, temp ; skip header
for i=0, n1-header_length-1 do begin
  readf, unit, temp1
  mcs_data(*,i)=temp1
endfor

close, unit
free_lun, unit

cext_ratio=2.2 ; ratio of dust Cext(1075 cm-1)/Cext(465cm-1) to convert MCS to TES dust opacity; 2.6, 2.2 and 1.9 for 1.0, 1.5 and 2.0 mkm dust

ind=where((mcs_data(1,*) eq lat1) and (mcs_data(2,*) gt 10)) ; find non-zero data in a latitudinal band
if (ind(0) ne -1) then begin
  ls=mcs_data(0,ind)
  mcs_dustsc=mcs_data(3,ind)
  mcs_dust=mcs_data(5,ind)
  loadct, 38, /silent  
  oplot, ls+dls/2., cext_ratio*mcs_dustsc, psym=-4, thick=3, color=220
 
; plot  legend
  oplot, x0, y0-0.45, psym=-4, thick=3,  color=220
  loadct, 0, /silent
  xyouts, x0[1]+5, y0[0]-0.45, 'MCS MY34'
endif  

device, /close
set_plot, 'win'

!p.charthick=1
!p.charsize=1
!x.thick=1
!y.thick=1

end